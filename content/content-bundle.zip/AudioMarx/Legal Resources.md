# Legal Resources

---

![](https://a.storyblok.com/f/137777/1200x630/20469e5fbb/og-image.jpg)

- [Tracklib](https://www.tracklib.com/) - Tracklib is the only service where anyone can legally clear samples from real music. From Isaac Hayes to Mozart, we got it.

**Date:** 2023-11-18T09:21:43.308Z
**Tags:** #Audio #legal

---

![](https://www.sheridans.co.uk/wp-content/uploads/bg-4.jpg)

- [Sheridans](https://www.sheridans.co.uk/) - Sheridans is a leading media and technology law firm whose lawyers combine in-depth legal and commercial knowledge with breadth of expertise and experience to give unparalleled advice to their clients. Since 1956, Sheridans has represented individuals and organisations across a wide variety of sectors, providing quality advice which is commercially focused and personally delivered. Specialist lawyers […]

**Date:** 2023-11-18T09:21:31.206Z
**Tags:** #Audio #legal

---

![](https://sampleclearance.com/wp-content/uploads/atf-background.jpg)

- [Sample Clearance](https://sampleclearance.com/) - ARTISTS WE HAVE RECENTLYOBTAINED CLEARANCES FOR INCLUDE Bastille / The Chemical Brothers / Tom Misch / Patrick Topping / Shy FX / Knife Party / Krept & Konan / Rihanna / Jamie Jones / Tion Wayne / Reinier Zonneveld / Duchess / Eats Everything / Scarlxrd / Pa Salieu / John Summit / Fraser T […]

**Date:** 2023-11-18T09:21:11.362Z
**Tags:** #Audio #legal

---

![](https://lickd.co/wp-content/uploads/2022/07/Share-Image.jpg)

- [Lickd](https://lickd.co/) - The only place you can license popular music for videos. Access 1M+ mainstream tracks, plus high-quality stock music for content creators

**Date:** 2023-11-18T09:20:43.212Z
**Tags:** #Audio #legal

---

![](https://v.fastcdn.co/u/fc90f930/61082041-0-lexoo-website.png)

- [Lexoo](https://info.lexoo.com/) - Lexoo helps in-house legal teams with smart playbooks, commercial contract reviews, as well as multi-country and repapering projects.

**Date:** 2023-11-18T09:20:14.082Z
**Tags:** #Audio #legal

---

![](https://dontsample.me/wp-content/uploads/2021/01/dontsampleme-logo-300x113.png)

- [DontSampleMe](https://dontsample.me/) - Home About / Contact Press Countless hours are wasted in the copyright battle between major labels and independent artists. This is the most comprehensive list of artists associated with major music labels that are issuing takedown notices across the internet. Hint: Red Highlight = popular artist .38 Special 10 Years 112 16 Frames 22 Jump … Home Read More "

**Date:** 2023-11-18T09:20:00.533Z
**Tags:** #Audio #legal

---

- [Creative Law & Business](https://creativelaw.eu/) - Expertly taking care of the law & the business of creativity.

**Date:** 2023-11-18T09:19:41.809Z
**Tags:** #Audio #legal

---

![](http://musiclawadvice.co.uk/uploads/8/1/5/7/81573936/original-on-transparent.png)

- [Music Law Advice](https://musiclawadvice.co.uk/index.html) - Independent Music Law Advice supplies advice and representation to a wide range of artists, bands and music related companies. ​You can contact us for any music law related advice and receive a totally independent service.

**Date:** 2023-11-18T09:18:49.842Z
**Tags:** #Audio #legal

---

![](https://www.bitlaw.com/images/gears2.jpg)

- [BitLaw](https://www.bitlaw.com/) - BITLAW: A FREE LEGAL RESOURCE
FOCUSING ON INTELLECTUAL PROPERTY

**Date:** 2023-11-18T09:18:12.392Z
**Tags:** #Audio #legal

---
