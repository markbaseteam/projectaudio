# Audio Information

---

![](https://www.bridge.audio/og-image.png)

- [Bridge Audio](https://www.bridge.audio/) - Bridge is for everyone working with music and audio. We provide private workspaces to manage, share, and connect better

**Date:** 2023-11-16T13:12:37.526Z
**Tags:** #Audio #information

---

- [UPCitemdb](https://upcitemdb.com/) - The largest UPC database offers API access, bulk lookup. With over 549 million barcodes, the database is updated daily and maintained by tech nerds.

**Date:** 2023-11-16T12:28:33.589Z
**Tags:** #Audio #UPC

---

- [ISRC Finder](https://www.isrcfinder.com/) - ISRC Search and Find tool utilising the largest ISRC database in the world - Spotify.

**Date:** 2023-11-16T12:28:11.476Z
**Tags:** #Audio #ISRC

---

![](https://adtunes.com/data/assets/logo/adtunes-logo-og.png)

- [Adtunes](https://adtunes.com/) - Find music used in TV commercials, television shows, movie trailers, film soundtracks, video games and more.

**Date:** 2023-11-16T12:45:23.556Z
**Tags:** #Audio #information

---

![](https://cdn-gce.allmusic.com/images/allmusic_facebook_share.png)

- [AllMusic](https://www.allmusic.com/) - AllMusic provides comprehensive music info including reviews and biographies. Get recommendations for new music to listen to, stream or own.

**Date:** 2023-11-16T12:43:12.337Z
**Tags:** #Audio #information

---

- [Note Discover](https://www.notediscover.com/) - Helping you find the BPM & key signature of your favorite songs

**Date:** 2023-11-16T12:32:38.432Z
**Tags:** #Audio #information

---

- [Yadb](https://www.yadb.com/) - YADB.com is a database for CD and track lookup. Using JRiver Media Center or Media Jukebox, you can lookup CDs and individual tracks. You can also submit information that we don't have yet. YADB was written and is copyrighted by JRiver.

**Date:** 2023-11-16T12:30:49.562Z
**Tags:** #Audio #information

---

- [VGMdb](https://vgmdb.net/) - VGMdb provides media, tracklist and artist information for video game soundtracks and anime music.

**Date:** 2023-11-16T12:29:16.914Z
**Tags:** #Audio #information

---
