# Crowdfunding

---

![](https://c15.patreon.com/OG_share_eaad746d69.jpg)

- [Home](https://www.patreon.com/) - Patreon is the best place to build community with your biggest fans, share exclusive work, and turn your passion into a lasting creative business.

**Date:** 2023-11-18T09:16:28.142Z
**Tags:** #Audio #crowdfunding

---

![](https://bpe.show4me.com/documents/additional-files/ce/a9/cea9cc01-0273-4d96-bf93-4b91ab51333c.png)

- [Show4me](https://show4me.com/) - Discover and listen to new music, follow artists, watch online concerts, buy albums, tickets, and merch.

**Date:** 2023-11-18T09:16:15.707Z
**Tags:** #Audio #crowdfunding

---

![](https://assets-global.website-files.com/604a7d8abe731579c1cdfd8b/64ece99cd40b0ad03a9bd9d3_60a5246574891b2ce2a7cb73_608f36d2b02b42ddc7fb24f4_royaltyexchnageheader%20(1)-p-500.webp)

- [Royalty Exchange](https://royaltyexchange.com/) - Royalty Exchange is an online marketplace & auction platform where investors & owners of royalty streams can buy royalties and sell all types of royalties.

**Date:** 2023-11-18T09:16:03.709Z
**Tags:** #Audio #crowdfunding

---

![](https://rocketfuelhq.com/assets/images/og_default_image.jpg)

- [Rocket Fuel](https://rocketfuelhq.com/) - Rocket Fuel enables fans to help their favourite artists to take off. Fans get exclusives and artists can fund their careers.

**Date:** 2023-11-18T09:15:47.859Z
**Tags:** #Audio #crowdfunding

---
